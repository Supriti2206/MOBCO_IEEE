import numpy as np
from normalization import normalize_fitness  # <-- ADD THIS

def crowding_distance_mixed(fitness_values, front_indices, objective_types):
    """
    min-max NORMALIZED fitness values so objectives
    on different scales contribute comparably.

    Parameters:
        fitness_values: (N, n_obj) full fitness array (front_indices index)
        front_indices: list/array of row indices into fitness_values that
                        belong to the front being measured
        objective_types: list like ['min', 'max', ...], one per objective;

    Returns:
        distances: array aligned POSITIONALLY with `front_indices` (i.e.
                    distances[i] is the crowding distance of front_indices[i]),

    Larger distance = more isolated / less crowded 
    """
    n_front = len(front_indices)
    distances = np.zeros(n_front)

    # With 2 or fewer points there's no meaningful "crowding"
    if n_front <= 2:
        distances[:] = np.inf
        return distances

    # Normalize
    normalized_fit = normalize_fitness(fitness_values, objective_types)

    n_obj = len(objective_types)

    for obj in range(n_obj):
        # Sort the front's *indices* by this objective's normalized value
        sorted_indices = sorted(front_indices, key=lambda idx: normalized_fit[idx, obj])

        distances[0] = np.inf
        distances[-1] = np.inf

        f_max = normalized_fit[sorted_indices[-1], obj]
        f_min = normalized_fit[sorted_indices[0], obj]

        if f_max != f_min:
            # Interior points: distance += normalized gap between neighbors
            for i in range(1, n_front - 1):
                idx = sorted_indices[i]
                prev_idx = sorted_indices[i - 1]
                next_idx = sorted_indices[i + 1]
                dist = (normalized_fit[next_idx, obj] - normalized_fit[prev_idx, obj]) / (f_max - f_min)
                distances[i] += dist  # accumulated across all objectives

    distances = np.nan_to_num(distances, nan=0.0, posinf=1e10)
    return distances


def sort_by_crowding_distance_mixed(population, fitness, front_indices, objective_types):
    # Sort solutions in a front by crowding distance (descending)
    distances = crowding_distance_mixed(fitness, front_indices, objective_types)
    sorted_indices = sorted(front_indices, key=lambda idx: distances[idx], reverse=True)
    return sorted_indices, distances