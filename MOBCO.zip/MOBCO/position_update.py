import numpy as np

def mobco_update_position(pop, Vt, t, acc, n, L, eye_flag, n_dogs=3):
    """
    Kinematic position update step of MOBCO: for each individual, compute a
    new position from the standard 1D kinematics equation
        x = v*t + 0.5*a*t^2
    applied independently per decision variable.

    Parameters:
        pop: (n, L) current population positions 
        Vt: (n, L) current velocities
        t: (n,) or (n, L) elapsed "time" step per individual
        acc: (n, L) current accelerations
        n: population size
        L: number of decision variables (dimensionality)
        eye_flag: 1 if the "eyeing"/stagnation behavior is active this
                  iteration 
        n_dogs: number of lead "dogs"

    Behavior:
        - The first n_dogs individuals (best/lead individuals after herding)
          always move using x = v*t + 0.5*a*t^2 
        - The remaining individuals use the same formula when
          eye_flag == 0, but flip the acceleration term's sign
          (x = v*t - 0.5*a*t^2) when eye_flag == 1, i.e. while the archive
          is stagnating -- this decelerates/reverses their exploratory push
          to encourage a change in search direction.

    """
    pop_new = np.zeros((n, L))

    for i in range(n):
        if i < n_dogs:  # First n_dogs individuals = lead "dogs" )
            pop_new[i] = Vt[i] * t[i] + 0.5 * acc[i] * (t[i] ** 2)
        else:
            if eye_flag == 1:
                # Stagnation detected: reverse the acceleration contribution
                pop_new[i] = Vt[i] * t[i] - 0.5 * acc[i] * (t[i] ** 2)
            else:
                pop_new[i] = Vt[i] * t[i] + 0.5 * acc[i] * (t[i] ** 2)
    return pop_new