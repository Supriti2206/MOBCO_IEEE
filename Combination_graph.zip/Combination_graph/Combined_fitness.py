"""
combine_fitness.py
-------------------
Purpose:
    Aap ke paas har algorithm ki results folder me (NSGA2_results, SPEA2_results,
    MOEAD_results, DSSEA_results, MOBCO_results) har test function ki ek .xlsx file
    hai. Us file ke "Pareto_Solutions" sheet me objective-wise fitness columns hote
    hain: f1_Objective_1, f2_Objective_2, f3_Objective_3, ... (jitne bhi objectives
    us test function ke hain).

    Ye script har xlsx file ko open karke un sab f1, f2, f3... columns ko DHOOND ta
    hai (chahe 2 ho, 3 ho ya 4 ho - count fixed nahi hai, script automatically detect
    karta hai), unhe COMBINE karke ek single "Combined_Fitness" value banata hai per
    solution/row, aur us file me ek NAYI SHEET ("Combined_Fitness") add kar deta hai.

Combination method (default):
    Objectives alag-alag scale par hote hain (e.g. ZDT ka f1 [0,1] range me hota hai,
    par EvoPINN ke losses ka scale bilkul alag hota hai). Isliye seedha sum lena
    galat hoga - ek objective dominate kar lega. Isliye:
        1. Har objective column ko us hi sheet ke andar MIN-MAX NORMALIZE kiya jata
           hai -> [0, 1] range me.
        2. Sab normalized objectives ka EQUAL-WEIGHT AVERAGE le kar Combined_Fitness
           banaya jata hai (sab objectives minimize hi hain is data me, isliye lower
           Combined_Fitness = behtar solution).
    Agar aapko weights different chahiye (kisi objective ko zyada importance dena ho)
    to niche WEIGHTS dict edit kar sakte hain. Agar sirf raw sum chahiye (bina
    normalize kiye), to USE_NORMALIZATION = False kar dijiye.

Output:
    Default: original files ko touch NAHI karta - ek naya output folder banata hai
    (OUTPUT_DIR, default: "<INPUT_DIR>_with_combined_fitness") jisme wahi folder
    structure aur wahi filenames hote hain, bas har file me ek extra sheet
    "Combined_Fitness" add hoti hai.

    Agar aap chahte hain ki ORIGINAL files me hi sheet add ho jaye (in-place), to
    niche OUTPUT_DIR = INPUT_DIR kar dijiye.

How to run:
    1. Neeche INPUT_DIR ko apne data folder ka path de dijiye (jisme *_results
       folders hain).
    2. Terminal me: python combine_fitness.py
    3. Sab test-function files process ho jayenge, progress print hoga.
"""

import os
import re
import glob
import openpyxl
from openpyxl.utils import get_column_letter

# ---------------------------------------------------------------------------
# CONFIG - yahan apni settings badal sakte hain
# ---------------------------------------------------------------------------

# Root folder jisme NSGA2_results, SPEA2_results, MOEAD_results, DSSEA_results,
# MOBCO_results jaisi sub-folders hain.
INPUT_DIR = "data"

# Output root folder. Default = INPUT_DIR + "_with_combined_fitness" (originals
# safe rehte hain). In-place overwrite karna ho to: OUTPUT_DIR = INPUT_DIR
OUTPUT_DIR = INPUT_DIR + "_with_combined_fitness"

# Kaunsi sheet me objective columns (f1_, f2_, ...) hain jinse combine karna hai.
SOURCE_SHEET = "Pareto_Solutions"

# Naya sheet ka naam jo add hoga.
OUTPUT_SHEET_NAME = "Combined_Fitness"

# True => har objective ko [0,1] me min-max normalize karke fir average lo
# (recommended, kyunki objectives ka scale alag-alag hota hai).
# False => seedha raw values ka sum le lo (sirf tab use karein jab sab
# objectives already same scale par hon).
USE_NORMALIZATION = True

# Custom weights (optional). None => sab objectives ko equal weight (1/n) diya
# jayega. Agar specific weight dena ho, dict use karein jaise:
#   WEIGHTS = {0: 0.5, 1: 0.3, 2: 0.2}   # index 0-based, f1->0, f2->1, f3->2
# Weights ka sum 1 hona zaroori nahi - script khud normalize kar lega.
WEIGHTS = None

# ---------------------------------------------------------------------------
# CODE - neeche generally badalne ki zarurat nahi
# ---------------------------------------------------------------------------

# f1_something, f2_something, ... jaise column headers pakadne ke liye pattern
F_COLUMN_PATTERN = re.compile(r"^f\d+(_.*)?$", re.IGNORECASE)


def find_objective_columns(header_row):
    """Header row (list of cell values) me se f1_, f2_, f3_... columns ke
    (index, name) pairs dhoondta hai, unke numeric suffix (f1, f2, f3) ke
    hisaab se sorted order me."""
    cols = []
    for idx, name in enumerate(header_row):
        if name is None:
            continue
        name_str = str(name).strip()
        if F_COLUMN_PATTERN.match(name_str):
            # f<number> ka number nikal lo taaki sahi order (f1, f2, ... f10) mile
            m = re.match(r"^f(\d+)", name_str, re.IGNORECASE)
            order_num = int(m.group(1)) if m else idx
            cols.append((order_num, idx, name_str))
    cols.sort(key=lambda t: t[0])
    return [(idx, name_str) for _, idx, name_str in cols]


def min_max_normalize(values):
    """List of floats -> list normalized to [0, 1]. Agar sab values same hain
    (max == min), to sabko 0.0 de diya jata hai (koi variation nahi to har
    solution equally good/bad maana jayega is objective ke liye)."""
    finite_vals = [v for v in values if v is not None]
    if not finite_vals:
        return [0.0] * len(values)
    vmin, vmax = min(finite_vals), max(finite_vals)
    span = vmax - vmin
    if span == 0:
        return [0.0 for _ in values]
    return [((v - vmin) / span) if v is not None else 0.0 for v in values]


def process_workbook(in_path, out_path):
    """Ek xlsx file open karke Pareto_Solutions se objectives combine karta
    hai aur naya sheet add karke out_path pe save karta hai."""

    # data_only=True copy sirf VALUES padhne ke liye (formulas evaluate ho kar
    # aaye hue). Main workbook (formulas ke saath) neeche alag se load karenge
    # taaki baaki sheets/formatting untouched rahe.
    values_wb = openpyxl.load_workbook(in_path, data_only=True)

    if SOURCE_SHEET not in values_wb.sheetnames:
        print(f"  [SKIP] '{SOURCE_SHEET}' sheet nahi mili: {in_path}")
        return False

    ws_values = values_wb[SOURCE_SHEET]
    rows = list(ws_values.iter_rows(values_only=True))
    if not rows:
        print(f"  [SKIP] Sheet khaali hai: {in_path}")
        return False

    header = rows[0]
    data_rows = rows[1:]

    obj_cols = find_objective_columns(header)
    if not obj_cols:
        print(f"  [SKIP] Koi f1_/f2_/... objective column nahi mili: {in_path}")
        return False

    # Solution / Best_Run columns (agar hon) reference ke liye rakh lete hain
    solution_idx = header.index("Solution") if "Solution" in header else None
    best_run_idx = header.index("Best_Run") if "Best_Run" in header else None

    n_rows = len(data_rows)
    n_obj = len(obj_cols)

    # Har objective column ke raw values nikal lo
    raw_matrix = []  # raw_matrix[obj_i] = list of raw values across rows
    for _, col_name in obj_cols:
        col_idx = header.index(col_name)
        raw_matrix.append([r[col_idx] for r in data_rows])

    # Normalize (agar enabled hai)
    if USE_NORMALIZATION:
        norm_matrix = [min_max_normalize(col) for col in raw_matrix]
    else:
        norm_matrix = raw_matrix

    # Weights decide karo
    if WEIGHTS is None:
        weights = [1.0 / n_obj] * n_obj
    else:
        w = [WEIGHTS.get(i, 0.0) for i in range(n_obj)]
        total = sum(w) or 1.0
        weights = [x / total for x in w]

    # Har row ke liye combined fitness = weighted average of (normalized) objectives
    combined = []
    raw_sum = []
    for r in range(n_rows):
        vals = [norm_matrix[o][r] for o in range(n_obj)]
        combined.append(sum(v * w for v, w in zip(vals, weights)))
        raw_sum.append(sum(raw_matrix[o][r] for o in range(n_obj) if raw_matrix[o][r] is not None))

    # ---- Ab naya workbook copy taiyar karte hain (formulas/formatting preserve
    # karne ke liye original file dobara load karo, is baar bina data_only) ----
    out_wb = openpyxl.load_workbook(in_path, data_only=False)

    if OUTPUT_SHEET_NAME in out_wb.sheetnames:
        del out_wb[OUTPUT_SHEET_NAME]
    ws_out = out_wb.create_sheet(OUTPUT_SHEET_NAME)

    # Header row banate hain: Solution, Best_Run, raw f-columns, Combined_Fitness, Raw_Sum
    out_header = []
    if solution_idx is not None:
        out_header.append("Solution")
    if best_run_idx is not None:
        out_header.append("Best_Run")
    out_header += [name for _, name in obj_cols]
    out_header.append("Combined_Fitness")
    out_header.append("Raw_Sum")
    ws_out.append(out_header)

    for r in range(n_rows):
        row_out = []
        if solution_idx is not None:
            row_out.append(data_rows[r][solution_idx])
        if best_run_idx is not None:
            row_out.append(data_rows[r][best_run_idx])
        row_out += [raw_matrix[o][r] for o in range(n_obj)]
        row_out.append(combined[r])
        row_out.append(raw_sum[r])
        ws_out.append(row_out)

    # Column widths thoda better dikhne ke liye
    for i, _ in enumerate(out_header, start=1):
        ws_out.column_dimensions[get_column_letter(i)].width = 18

    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    out_wb.save(out_path)
    print(f"  [OK] {n_rows} rows, {n_obj} objectives -> {out_path}")
    return True


def main():
    pattern = os.path.join(INPUT_DIR, "*_results", "*.xlsx")
    files = sorted(glob.glob(pattern))

    if not files:
        print(f"Koi .xlsx file nahi mili is pattern se: {pattern}")
        print("INPUT_DIR sahi set kiya hai? Abhi INPUT_DIR =", os.path.abspath(INPUT_DIR))
        return

    print(f"{len(files)} files milin. Processing shuru...")
    ok_count = 0
    for in_path in files:
        rel = os.path.relpath(in_path, INPUT_DIR)
        out_path = os.path.join(OUTPUT_DIR, rel)
        print(f"Processing: {rel}")
        if process_workbook(in_path, out_path):
            ok_count += 1

    print(f"\nDone. {ok_count}/{len(files)} files me Combined_Fitness sheet add hui.")
    print(f"Output folder: {os.path.abspath(OUTPUT_DIR)}")


if __name__ == "__main__":
    main()