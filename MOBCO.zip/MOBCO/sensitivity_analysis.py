"""
python sensitivity_analysis.py --study structural --base-n 16
python sensitivity_analysis.py --study shaping --base-n 16
python sensitivity_analysis.py --study both --base-n 16    
"""

import argparse
import time
from pathlib import Path

import numpy as np
import pandas as pd

try:
    from SALib.sample.sobol import sample as sobol_sample
except ImportError:
    from SALib.sample.saltelli import sample as sobol_sample
from SALib.analyze import sobol

from config import MOBCOConfig
from dataset import get_problem
from metrics import MetricContext, hypervolume
from optimizer import MOBCO

ROOT = Path(__file__).resolve().parent
_DEFAULTS = MOBCOConfig()

STUDIES = {
    'structural': {
        'num_vars': 5,
        'names': ['n_population', 'n_dogs', 'mutation_rate',
                  'archive_size', 'eyeing_steps'],
        'bounds': [
            [20, 350],     # n_population 
            [2, 8],        # n_dogs
            [0.01, 0.4],   # mutation_rate
            [20, 350],     # archive_size 
            [2, 12],       # eyeing_steps
        ],
        'is_int': [True, True, False, True, True],
    },
    'shaping': {
        'num_vars': 5,
        'names': ['acc_damping', 'mutation_decay_floor', 'step_decay_floor',
                  'stalking_pull', 'gathering_pull'],
        'bounds': [
            [0.5, 0.99],   # acc_damping
            [0.0, 0.5],    # mutation_decay_floor
            [0.0, 0.5],    # step_decay_floor
            [0.5, 4.0],    # stalking_pull  
            [0.1, 2.0],    # gathering_pull 
        ],
        'is_int': [False, False, False, False, False],
    },
}


def _cast_row(row, study):
    params = {
        'n_population': _DEFAULTS.n_population,
        'n_dogs': _DEFAULTS.n_dogs,
        'mutation_rate': _DEFAULTS.mutation_rate,
        'archive_size': _DEFAULTS.archive_size,
        'eyeing_steps': _DEFAULTS.eyeing_steps,
        'acc_damping': _DEFAULTS.acc_damping,
        'mutation_decay_floor': _DEFAULTS.mutation_decay_floor,
        'step_decay_floor': _DEFAULTS.step_decay_floor,
        'stalking_pull': _DEFAULTS.stalking_pull,
        'gathering_pull': _DEFAULTS.gathering_pull,
    }
    spec = STUDIES[study]
    for name, is_int, value in zip(spec['names'], spec['is_int'], row):
        if name == 'n_dogs':
            params[name] = max(2, int(round(value)))
        elif name == 'eyeing_steps':
            params[name] = max(1, int(round(value)))
        elif is_int:
            params[name] = int(round(value))
        else:
            params[name] = float(value)
    return params


def _make_config(params, sa_iterations, sa_seed):
    cfg = MOBCOConfig()
    for k, v in params.items():
        setattr(cfg, k, v)
    cfg.max_iterations = sa_iterations
    cfg.verbose = False
    cfg.base_seed = sa_seed
    return cfg


def _final_hv(problem, cfg, seed):
    res = MOBCO(problem, cfg, seed=seed).run()
    front = res['front']
    if front.size == 0:
        return 0.0
    tf = problem.get('true_front')
    if tf is not None:
        # true_front is a GENERATOR FUNCTION 
        ref_front = np.asarray(tf(1000), dtype=float)
    else:
        # no analytic PF  use the archive itself
        ref_front = front
    if ref_front is None or len(ref_front) == 0:
        ref_front = front
    ctx = MetricContext(ref_front, problem['objective_types'], seed=seed)
    hv = hypervolume(front, ctx, n_samples=2000)
    return 0.0 if np.isnan(hv) else hv


def evaluate_row(row, study, problems, sa_iterations, sa_replicates):
    """Model output Y for one sampled parameter set: mean HV across
    problems and replicate seeds"""
    params = _cast_row(row, study)
    hv_values = []
    for pname in problems:
        problem = get_problem(pname)
        cfg = _make_config(params, sa_iterations, sa_seed=2000)
        for r in range(sa_replicates):
            hv_values.append(_final_hv(problem, cfg, seed=cfg.base_seed + r))
    return float(np.mean(hv_values))


def run_study(study, base_n, sa_iterations, sa_replicates, problems):
    """
    Run one full Sobol sensitivity study end to end: build the Sobol sample
    matrix, evaluate every sampled parameter combination 
    compute first- and total-order Sobol indices
    """
    problem_def = {'num_vars': STUDIES[study]['num_vars'],
                   'names': STUDIES[study]['names'],
                   'bounds': STUDIES[study]['bounds']}

    param_values = sobol_sample(problem_def, base_n, calc_second_order=False)
    n_runs = len(param_values)
    print(f"\n[{study}] Sobol SA: {n_runs} MOBCO calls "
          f"({sa_iterations} iters x {sa_replicates} seeds x "
          f"{len(problems)} problems each; other 5 params frozen at defaults)")

    Y = np.empty(n_runs)
    t0 = time.perf_counter()
    for i, row in enumerate(param_values, 1):
        Y[i - 1] = evaluate_row(row, study, problems, sa_iterations, sa_replicates)
        if i % max(1, n_runs // 20) == 0 or i == n_runs:
            elapsed = time.perf_counter() - t0
            print(f"  [{study}] {i}/{n_runs}  (elapsed {elapsed/60:.1f} min)")

    Si = sobol.analyze(problem_def, Y, calc_second_order=False, print_to_console=False) 
    raw_table = pd.DataFrame(param_values, columns=problem_def['names'])
    raw_table['hv_score'] = Y
    raw_table = raw_table.sort_values('hv_score', ascending=False)
    raw_out_path = ROOT / 'results' / f'sensitivity_raw_runs_{study}.xlsx'
    (ROOT / 'results').mkdir(exist_ok=True)
    raw_table.to_excel(raw_out_path, index=False)
    print(f"saved raw per-run data -> {raw_out_path}")

    table = pd.DataFrame({
        'parameter': problem_def['names'],
        'S1_first_order': Si['S1'],
        'ST_total_order': Si['ST'],
        'S1_conf': Si['S1_conf'],
        'ST_conf': Si['ST_conf'],
    }).sort_values('ST_total_order', ascending=False)

    print(f"\n=== [{study}] Sobol sensitivity indices (higher = more influence on HV) ===")
    print(table.to_string(index=False))

    out_dir = ROOT / 'results'
    out_dir.mkdir(exist_ok=True)
    out_path = out_dir / f'sensitivity_analysis_{study}.xlsx'
    table.to_excel(out_path, index=False)
    print(f"saved -> {out_path}")
    return table
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--study', choices=['structural', 'shaping', 'both'],
                    default='both',
                    help='which 5-parameter group to analyze')
    ap.add_argument('--base-n', type=int, default=16,
                    help='Saltelli/Sobol base sample size N '
                         '(total runs per study = N * (num_vars + 2); '
                         'num_vars=5 per study, so N=16 -> 112 runs/study)')
    ap.add_argument('--sa-iterations', type=int, default=50,
                    help='MOBCO max_iterations during SA (keep small)')
    ap.add_argument('--sa-replicates', type=int, default=3,
                    help='seeds averaged per parameter set')
    ap.add_argument('--problems', nargs='*',
                    default=['ZDT1', 'DTLZ2', 'EvoPINN1_Poisson1D'])
    args = ap.parse_args()

    studies = ['structural', 'shaping'] if args.study == 'both' else [args.study]
    for study in studies:
        run_study(study, args.base_n, args.sa_iterations,
                  args.sa_replicates, args.problems)


if __name__ == '__main__':
    main()