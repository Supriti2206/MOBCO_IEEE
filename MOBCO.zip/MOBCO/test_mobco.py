"""
Minimal smoke test: run MOBCO once on Mixed_ZDT1
"""

import numpy as np
from dataset import get_problem
from optimizer import MOBCO
from config import MOBCOConfig

cfg = MOBCOConfig(n_population=100, n_dogs=3, archive_size=200,
                  max_iterations=200, n_runs=50)
problem = get_problem('Mixed_ZDT1')

mobco = MOBCO(problem, cfg, seed=42)
result = mobco.run()

print(f"Front size: {len(result['front'])}")
print(f"First 3 solutions:\n{result['front'][:3]}")
print(f"Function evaluations: {result['n_eval']}")
print(f"Runtime: {result['runtime']:.3f}s")