import numpy as np

def mobco_fitness(population, n, dim, fobj, n_obj, objective_types=None):
    """
    Parameters:
        population: (n, dim) array of candidate solutions (decision vectors)
        n: number of individuals in the population
        dim: number of decision variables per individual
        fobj: the objective function; called as fobj(individual) and expected to
              return a length-n_obj 
        n_obj: number of objectives

    Returns:
        fitness: (n, n_obj) array where row i holds the objective values for
                  population[i]
    """
    # If no types specified, all are minimization
    if objective_types is None:
        objective_types = ['min'] * n_obj
    fitness = np.zeros((n, n_obj))
    for i in range(n):
        fitness[i, :] = fobj(population[i, :])
    return fitness